var elem = function()
{
    var sel = document.getItemById("e").value;
    console.log(sel);
}