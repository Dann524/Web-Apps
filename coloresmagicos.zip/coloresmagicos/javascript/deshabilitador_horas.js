var Apagado = function()
{
	document.getElementById("h1").disabled=true;
	document.getElementById("h2").disabled=true;
	document.getElementById("h3").disabled=true;
	document.getElementById("h4").disabled=true;
	document.getElementById("h5").disabled=true;
	document.getElementById("h6").disabled=true;

	document.getElementById("s1").disabled=true;
	document.getElementById("s2").disabled=true;
	document.getElementById("s3").disabled=true;
	document.getElementById("s4").disabled=true;
	document.getElementById("s5").disabled=true;
	document.getElementById("s6").disabled=true;

	document.getElementById("enviar").disabled=true;

	document.getElementById("descuento").disabled=true;
}