var cuponera = function()
{
	var cupon = document.getElementById("codigo").value;
	console.log("codigo es: " + cupon);
	document.getElementById("descuento").disabled=false;
}