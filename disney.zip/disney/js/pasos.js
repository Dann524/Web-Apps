function pasos()
{
    //Obtenemos el valor del campo de correo electrónico
    var email = document.getElementById("mail").value;
    
    // Define our regular expression.
	var validEmail =  /^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/;

	// Using test we can check if the text match the pattern
	if( validEmail.test(email) )
    {
        //Si el correo es campo válido, dirigimos a la página del paso 2
        window.location = "suscripcion/acuerdo.html"
    }
    else
    {
        document.getElementById("errormail").className = "visible";
        document.getElementById('mail').style.border='1px solid #FF554C';
    }
}

//WDC (MEXICO), S. DE R.L. DE C.V. ("Disney", "nosotros", "nos", "nuestro") con domicilio social en Periférico Sur 3299, Piso 11, Colonia Fuentes del Pedregal, Alcaldía Tlalpan, 14140, CDMX y número de identificación fiscal WME920221837 te da la bienvenida al Servicio Disney y/o Servicio STAR+.(i) El “Servicio Disney+” es un servicio de suscripción de “streaming” de video personalizado que incluye el sitio web, la aplicación y el contenido y los servicios relacionados de Disney+.(ii) El “Servicio STAR+” es un servicio de suscripción de streaming de video personalizado que incluye el sitio web, la aplicación y el contenido y los servicios relacionados de STAR+.