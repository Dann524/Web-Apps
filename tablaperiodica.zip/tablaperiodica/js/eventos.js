function flote()
{
    var videoelem = getElementsByTagName("iframe");
    
}