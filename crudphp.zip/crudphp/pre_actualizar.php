<!DOCTYPE html>
<html>
<head>
	<title>Actualizar datos</title>
</head>
<body>
	<form>
		<label for="nombre">Nombre: </label>
		<input type="text" name="nombre" id="nombre">
		<label for="nombre2">Nombre 2: </label>
		<input type="text" name="nombre2" id="nombre2">
		<button type="submit">Enviar y actualizar</button>
	</form>

</body>
</html>